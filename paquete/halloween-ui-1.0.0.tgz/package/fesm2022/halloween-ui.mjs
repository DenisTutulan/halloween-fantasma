import * as i0 from "@angular/core";
import { Component, Input } from "@angular/core";
import * as i1 from "@angular/common";
import { CommonModule } from "@angular/common";
var HalloweenUi = class HalloweenUi {
	constructor() {}
	ngOnInit() {}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.5",
			ngImport: i0,
			type: HalloweenUi,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.5",
			type: HalloweenUi,
			isStandalone: true,
			selector: "lib-halloween-ui",
			ngImport: i0,
			template: "<p>halloween-ui works!</p>\n",
			styles: [""]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: HalloweenUi,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-halloween-ui",
			imports: [],
			template: "<p>halloween-ui works!</p>\n"
		}]
	}],
	ctorParameters: () => []
});
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.titulo = "Fantasma";
		this.descripcion = "Un espíritu misterioso.";
		this.imagen = "assets/img/fantasma.png";
		this.textoBoton = "Descubrir";
		this.informacionExtra = "";
		this.mostrarInfo = false;
	}
	mostrarMensaje() {
		this.mostrarInfo = !this.mostrarInfo;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.5",
			ngImport: i0,
			type: MonsterCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.5",
			type: MonsterCardComponent,
			isStandalone: true,
			selector: "lib-monster-card",
			inputs: {
				titulo: "titulo",
				descripcion: "descripcion",
				imagen: "imagen",
				textoBoton: "textoBoton",
				informacionExtra: "informacionExtra"
			},
			ngImport: i0,
			template: "\n<div class=\"monster-card\">\n\n  <img [src]=\"imagen\" [alt]=\"titulo\">\n\n  <div class=\"contenido\">\n\n    <h2>{{ titulo }}</h2>\n\n    <p>{{ descripcion }}</p>\n\n    <button type=\"button\" (click)=\"mostrarMensaje()\">\n      {{ mostrarInfo ? 'Ocultar información' : textoBoton }}\n    </button>\n\n    <div class=\"informacion\" *ngIf=\"mostrarInfo\">\n      <p>{{ informacionExtra }}</p>\n    </div>\n\n  </div>\n\n</div>\n",
			styles: [".monster-card{background:#21152f;border:2px solid #a66cff;border-radius:15px;padding:15px;margin:15px;text-align:center;color:#fff;box-shadow:0 0 15px #8e44ad}.monster-card img{width:100%;max-height:200px;object-fit:contain;border-radius:10px}.contenido h2{color:#d5b8ff;margin-top:12px}.contenido p{color:#eee}button{background:#a66cff;color:#fff;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;margin-top:10px}button:hover{background:#7d3cbd}.informacion{background:#382450;border:1px solid #c4a5ff;border-radius:10px;padding:10px;margin-top:15px;animation:aparecer .4s ease}.informacion p{color:#e5d5ff}@keyframes aparecer{0%{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}\n"],
			dependencies: [{
				kind: "ngmodule",
				type: CommonModule
			}, {
				kind: "directive",
				type: i1.NgIf,
				selector: "[ngIf]",
				inputs: [
					"ngIf",
					"ngIfThen",
					"ngIfElse"
				]
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			standalone: true,
			imports: [CommonModule],
			template: "\n<div class=\"monster-card\">\n\n  <img [src]=\"imagen\" [alt]=\"titulo\">\n\n  <div class=\"contenido\">\n\n    <h2>{{ titulo }}</h2>\n\n    <p>{{ descripcion }}</p>\n\n    <button type=\"button\" (click)=\"mostrarMensaje()\">\n      {{ mostrarInfo ? 'Ocultar información' : textoBoton }}\n    </button>\n\n    <div class=\"informacion\" *ngIf=\"mostrarInfo\">\n      <p>{{ informacionExtra }}</p>\n    </div>\n\n  </div>\n\n</div>\n",
			styles: [".monster-card{background:#21152f;border:2px solid #a66cff;border-radius:15px;padding:15px;margin:15px;text-align:center;color:#fff;box-shadow:0 0 15px #8e44ad}.monster-card img{width:100%;max-height:200px;object-fit:contain;border-radius:10px}.contenido h2{color:#d5b8ff;margin-top:12px}.contenido p{color:#eee}button{background:#a66cff;color:#fff;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;margin-top:10px}button:hover{background:#7d3cbd}.informacion{background:#382450;border:1px solid #c4a5ff;border-radius:10px;padding:10px;margin-top:15px;animation:aparecer .4s ease}.informacion p{color:#e5d5ff}@keyframes aparecer{0%{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}\n"]
		}]
	}],
	propDecorators: {
		titulo: [{ type: Input }],
		descripcion: [{ type: Input }],
		imagen: [{ type: Input }],
		textoBoton: [{ type: Input }],
		informacionExtra: [{ type: Input }]
	}
});
export { HalloweenUi, MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map